# CSV business data transfers

Implemented from the 2026-09-13 CSV audit. Business Server remains the local operational authority. Actions use its authenticated local API and work offline.

## Screen coverage

| Screens / datasets                                       | Templates and import                                      | Export                                            |
| -------------------------------------------------------- | --------------------------------------------------------- | ------------------------------------------------- |
| Categories, brands, units, warehouses                    | Yes; stable code references                               | Yes                                               |
| Products, unit conversions, barcodes, prices             | Yes; explicit updates and price history                   | Yes                                               |
| Customers, suppliers                                     | Yes; master records only                                  | Yes                                               |
| Opening stock / inventory                                | Opening stock with movements, approval and backup         | Yes                                               |
| Opening receivables / payables                           | Opening ledger entries, approval and backup               | Yes                                               |
| Purchases                                                | Separate headers and lines; draft first, explicit receipt | Yes                                               |
| Stock counts                                             | Draft first, explicit approval                            | Yes                                               |
| Service categories, services, branch prices              | Yes, when service module is enabled                       | Yes                                               |
| Users, bank/cash accounts, payment methods, terminals    | Export only                                               | Yes; restricted fields and masked bank references |
| Sharing formulas, shareholders, ownership, commissions   | Export only                                               | Yes                                               |
| Reports, sales, expenses, settlements, staff performance | No historical transaction import                          | Yes; all matching rows                            |

P2 imports for staff/configuration, ownership, transfers, adjustments and historical transactions remain excluded as specified in the audit. They need separate product decisions and business rules. Posted transactions cannot be overwritten through CSV.

## Owner workflow

1. Open Administration > Data transfers, or the CSV toolbar on a relevant screen.
2. Download the setup ZIP containing empty templates, separate fictional examples and column guides. Give the owner the templates and guides. Preserve schema_version and stable codes.
3. Fill reference lists before product/customer/supplier data. Use YYYY-MM-DD dates and plain decimals. Preserve leading zeros when editing spreadsheets.
4. Upload one or several files, select datasets/delimiters and map columns. Create-only is the default; choose explicit update mode for supported masters. Blank optional values preserve existing fields on update.
5. Validate the private database snapshot, review counts/actions/totals and download row errors. Validation makes no operational changes. The preview shows up to 100 rows; totals cover the complete upload.
6. Confirm and commit. Opening stock/debts require opening approval permission and a successful pre-import backup. Commits run in bounded chunks; history supports resume after interruption. Cancellation preserves completed chunks.
7. Review purchase/count drafts before posting. Select the purchase warehouse and confirm receipt. Count approval rejects a stale stock snapshot, requiring a fresh count.
8. Export from the screen or central browser. Report filters apply to report exports; the CSV panel search applies to dataset exports. Downloads include all matching rows, beyond the displayed page.

## Rules and limits

- Up to 30 files, 8 MiB total and 10,000 rows per import, 64 columns and 8,192 characters per field. UTF-8, BOM, comma/semicolon delimiters and quoted multiline fields are supported.
- Version 1 templates match by codes, SKUs and source IDs, never ambiguous names. Duplicate receipts persist after preview expiry. Conflicting reused identities are rejected.
- Opening stock requires no previous activity for that product/location. Use base units, one row per product/location, at most one batch per row, and pipe-separated unique serials matching the quantity.
- Opening debt is positive NGN, one consolidated row per zero-history account. Negative credits and cash/bank opening balances are outside this version. Overdue dates are allowed; future as-of dates are rejected.
- CSV purchase drafts support full receipt. Partial receipts, advanced landed costs and batch-specific purchase lines use the existing operational workflow.
- Exports use a consistent snapshot and bounded batches, capped at 256 MiB, with authenticated chunk downloads. Text cells protect spreadsheet formula prefixes and leading-zero/long identifiers; versioned imports undo that protective prefix.
- Stale previews cannot overwrite later changes. Each completed chunk atomically stores its operational changes, audit, sync outbox and duplicate checkpoints. Conflicts stop remaining chunks for review.

## Permissions, recovery and contracts

Schema migration 4 adds data.templates, data.validate, data.commit, data.export and data.approve_opening for Owner/Administrator. Every action also requires existing domain permissions. Service module gates apply even to owners. Job/download access is scoped to the initiating actor and configured branch; permissions are checked again at commit/download.

Private temporary directories have restricted access. Exports expire after 24 hours; detailed non-running previews expire after seven days. Audit and duplicate receipts remain. Startup marks interrupted validation/export jobs failed and removes temporary snapshots. Approved/running commits remain resumable. Hourly cleanup retries failures. Existing backup retention applies to opening backups.

Migration is additive: jobs/checkpoints/exports, stable brand/service-category codes, supplier opening ledger, CSV purchase drafts and sync versions. Supplier statements include opening_balance entries. CSV sync snapshots use existing Platform entity names and UUIDs, monotonically increasing versions and no local numeric IDs. Generic non-CSV worker behaviour is preserved.

## Verification and rollout

    npm run typecheck
    npm run build
    npm run test:readiness
    npm run test:csv:e2e

Backend tests use temporary SQLite databases and HTTP routes, covering parsing, dependencies, duplicates, stale previews, atomicity, opening ledgers/stock, draft posting, permissions, branch/module gates, chunk resume, full exports, archives, cleanup and mocked offline synchronization. The browser test covers template download, preview, confirmation, import and export with a mocked API.

Before production rollout, pilot sanitized owner files on target hardware, verify backup restore, reconcile stock/debt totals and confirm end-to-end Platform synchronization, including subsequent non-CSV balance changes. Measure maximum uploads and large exports alongside normal server traffic. Complete existing signed-installer release checks. Automated checks do not establish production pilot or installer readiness.

## Verification record: 2026-09-13

| Check                                                                                        | Result                                                                                              |
| -------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------- |
| Typecheck                                                                                    | Passed                                                                                              |
| Main, preload and renderer production build                                                  | Passed                                                                                              |
| Readiness suite                                                                              | 75 tests passed across 9 files, including 33 CSV tests                                              |
| Purchasing, customer debt, inventory routes, local reporting and synchronization regressions | 14 tests passed across 5 files                                                                      |
| CSV owner browser workflow                                                                   | 1 passed; mocked API, Microsoft Edge on Windows                                                     |
| 10,000-product preview and commit                                                            | Passed: 100 chunks; approximately 38 seconds alone and 63 seconds during concurrent build/test work |
| Complete export                                                                              | 2,101-product fixture passed, plus empty datasets/reports and filtered exports                      |

Measurements use synthetic temporary databases on the development Windows machine with the Electron SQLite test runner. No production data, packaged installer, target-hardware checkout latency or live receiving Platform was used.

## Common errors and corrections

- Missing reference: import the required category/unit/warehouse/customer/supplier code first, or include its file in the same validation batch.
- Duplicate/conflicting identity: keep a stable source ID. Exact repeats skip completed records; a changed opening or document under the same ID cannot replace its committed history.
- Changed data after preview: export the latest values and validate the remaining data again. Previously completed records remain committed.
- Interrupted job: open history and resume an approved/running import. Interrupted validation must be uploaded again. An expired preview must be revalidated.
- Opening already exists: do not invent another source ID to bypass the rule. Reconcile against the opening receipt and current stock/ledger. Correct posted errors through an authorized movement or compensating ledger transaction in the operational workflow. This CSV release does not supply a reversal wizard.
- Restore: use the existing backup/recovery workflow only after assessing all trading since the backup; restoring removes subsequent changes. Reconcile business totals and synchronization after recovery.
